Jupiter Modules needed for MMA
bas.f90
gdt.f90
typ.f90
utl.f90
sta.f90
dep.f90
eqn.f90
because utlucode is used: 
pri.f90
sen.f90 
UCODE modules needed for MMA
utlucode.f90 for reading extended _dm file
