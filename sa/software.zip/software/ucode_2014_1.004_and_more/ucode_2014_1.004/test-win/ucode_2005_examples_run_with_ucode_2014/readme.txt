Directory: "ucode_2005_examples_run_with_ucode_2014" includes two of the
examples distribued with UCODE_2005, but executed with UCODE_2014
These examples are described in the UCODE_2005 manual which is included
in the doc directory
  ex1a (supporting files are in ex1a-files and in ..\test-data-win)
  ex1b (supporting files are in ex1b-files and in ..\test-data-win)