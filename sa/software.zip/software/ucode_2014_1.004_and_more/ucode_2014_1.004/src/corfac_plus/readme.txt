Jupiter Modules needed for corfac_plus
bas.f90
dep.f90
eqn.f90
gdt.f90
pri.f90
sen.f90
sta.f90
typ.f90
utl.f90
UCODE Modules needed for corfac_plus
utlucode.f90
