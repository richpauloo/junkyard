Jupiter Modules needed for ucode_2014
bas.f90
dep.f90
eqn.f90
gdt.f90
mio.f90
pll.f90
pri.f90
sen.f90
sta.f90
typ.f90
utl.f90
UCODE Modules needed for ucode_2014
utlucode.f90

